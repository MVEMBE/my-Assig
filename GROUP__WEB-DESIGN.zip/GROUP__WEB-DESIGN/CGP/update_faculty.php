<?php

require_once 'db_connection.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    $faculty_id = $_POST['faculty_id'];
    $name = $_POST['name'];

    $query = "UPDATE students SET name = ? WHERE faculty_id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("sssisi", $name, $faculty_id);

    if ($stmt->execute()) {
        echo "Faculty information updated successfully!";
    } else {
        echo "Error updating Faculty: " . $stmt->error;
    }

    $stmt->close();
    
    header("Location: institute_dashboard.php?id=" . $id);
    exit;
}
