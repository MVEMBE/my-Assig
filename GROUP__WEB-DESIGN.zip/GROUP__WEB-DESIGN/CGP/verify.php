
<?php
include('db_connection.php');

if (isset($_GET['token'])) {
    $token = $_GET['token'];

    $query = "SELECT * FROM users WHERE verification_token = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("s", $token);
    $stmt->execute();
    $result = $stmt->get_result();
    $user = $result->fetch_assoc();

    if ($user) {
        $updateQuery = "UPDATE users SET status = 'active', verification_token = NULL WHERE verification_token = ?";
        $updateStmt = $conn->prepare($updateQuery);
        $updateStmt->bind_param("s", $token);
        $updateStmt->execute();

        echo "Your email has been successfully verified. You can now log in.";
    } else {
        echo "Invalid or expired verification link.";
    }
}

