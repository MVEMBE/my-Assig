
<?php
// Include database connection
require_once 'db.php';

// Check if the form is submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Get form data
    $id = $_POST['id'];
    $name = $_POST['name'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $age = $_POST['age'];
    $course = $_POST['course'];

    // Prepare the SQL statement to update the student data
    $query = "UPDATE students SET name = ?, email = ?, phone = ?, age = ?, course = ? WHERE id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("sssisi", $name, $email, $phone, $age, $course, $id);

    // Execute the update query
    if ($stmt->execute()) {
        echo "Student information updated successfully!";
    } else {
        echo "Error updating student: " . $stmt->error;
    }

    // Close the statement
    $stmt->close();
    
    // Redirect back to the edit page (or another page) after update
    header("Location: edit.php?id=" . $id);
    exit;
}
?>

