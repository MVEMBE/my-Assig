
function openNav() {
  document.getElementById("mv-nav").style.width = "250px";
  document.getElementById("mv").style.marginLeft = "250px";
  document.body.style.backgroundColor = "rgba(0,0,0,0.4)";
}

function closeNav() {
  document.getElementById("mv-nav").style.width = "0";
  document.getElementById("mv").style.marginLeft= "0";
  document.body.style.backgroundColor = " #081B29";
}