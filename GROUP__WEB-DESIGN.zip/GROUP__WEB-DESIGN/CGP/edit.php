
<?php
// Include database connection
require_once 'db.php';

// Check if the ID is provided in the URL
if (isset($_GET['id'])) {
    $id = $_GET['id'];

    // Prepare the SQL statement to fetch student data
    $query = "SELECT * FROM students WHERE id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();

    // Check if data was found
    if ($result->num_rows > 0) {
        $student = $result->fetch_assoc();
    } else {
        echo "No data found.";
        exit;
    }
} else {
    echo "ID not provided.";
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Student</title>
</head>
<body>

<h2>Edit Student Information</h2>

<form action="update.php" method="post">
    <input type="hidden" name="id" value="<?php echo $student['id']; ?>">
    
    <label for="name">Name:</label>
    <input type="text" name="name" value="<?php echo htmlspecialchars($student['name']); ?>" required><br><br>

    <label for="email">Email:</label>
    <input type="email" name="email" value="<?php echo htmlspecialchars($student['email']); ?>" required><br><br>

    <label for="phone">Phone:</label>
    <input type="text" name="phone" value="<?php echo htmlspecialchars($student['phone']); ?>"><br><br>

    <label for="age">Age:</label>
    <input type="number" name="age" value="<?php echo htmlspecialchars($student['age']); ?>" required><br><br>

    <label for="course">Course:</label>
    <input type="text" name="course" value="<?php echo htmlspecialchars($student['course']); ?>"><br><br>

    <button type="submit">Update Student</button>
</form>

</body>
</html>
<tr>
                <th>Name</th>
                <th>Type</th>
                <th>Address</th>
                <th>Contact</th>
                <th>Actions</th>
            </tr>