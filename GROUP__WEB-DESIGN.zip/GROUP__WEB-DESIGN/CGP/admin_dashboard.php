<?php
session_start();
if ($_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit;
}

include('db_connection.php');

$query = "SELECT * FROM institutions";
$result = $conn->query($query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="style.css">
    
</head>
<body>
    <div class="man">
        <header>
            <h2>Admin Dashboard</h2>
        </header>

        <div>
            <button class="canadd"><a href="ad_institute.php">Add New Institution</a></button>
        </div>

        <h3>Existing Institutions</h3>
        <table>
            <tr>
                <th>Name</th>
                <th>Type</th>
                <th>Address</th>
                <th>Contact</th>
                <th>Actions</th>
            </tr>
            <?php while ($institution = $result->fetch_assoc()) { ?>
            <tr>
                <td><?= $institution['name']; ?></td>
                <td><?= $institution['type']; ?></td>
                <td><?= $institution['address']; ?></td>
                <td><?= $institution['contact']; ?></td>
                <td class="act-but">
                   <button class="canadd"> <a href="edit_institution.php?id=<?= $institution['institution_id']; ?>">Edit</a></button>
                   <button class="canaddy"> <a href="delete_institution.php?id=<?= $institution['institution_id']; ?>">Delete</a></button>
                </td>
            </tr>
            <?php } ?>
        </table>
    </div>
</body>
</html>
