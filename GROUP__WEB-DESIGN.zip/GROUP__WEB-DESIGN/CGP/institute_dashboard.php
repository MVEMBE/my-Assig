<?php
session_start();
if ($_SESSION['role'] !== 'institute') {
    header("Location: login.php");
    exit;
}

include('db_connection.php');

$institution_id = $_SESSION['institution_id'];

$query = "SELECT * FROM faculties WHERE institution_id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $institution_id);
$stmt->execute();
$faculties_result = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Institute Dashboard</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="man">
        <header>
            <h2>Institute Dashboard</h2>
        </header>

        <div>
            <button> <a href="ad_faculty.php"> Add Faculty</a></button>
        </div>
        <div>
            <button class="canaddy"> <a href="add_course.php?faculty_id=<?= $faculty['faculty_id']; ?>">Add Course</a><button>
        </div>
    
        <h3>Existing Faculties</h3>
        <table>
            <tr>
                <th>Name</th>
                <th>Actions</th>
            </tr>
                <?php while ($faculty = $faculties_result->fetch_assoc()) { ?>
            <tr>
                <td><?= $faculty['name']; ?></td>
               <td>
                    <button class="canadd"> <a href="edit_faculty.php?id=<?= $faculty['institution_id']; ?>">Edit</a></button>
                    <button class="canaddy"> <a href="delete_faculty.php?id=<?= $faculty['institution_id']; ?>">Delete</a></button>
               </td>
            </tr>
            <?php } ?>
        </table>
    </div>
</body>
</html>
