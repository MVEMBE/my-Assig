<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'vendor/autoload.php';

include('db_connection.php');

if (isset($_POST['signup'])) {
    
    $username = htmlspecialchars(trim($_POST['username']));
    $email = filter_var(trim($_POST['email']), FILTER_SANITIZE_EMAIL);
    $password = $_POST['password'];
    $role = $_POST['role'];

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        echo "Invalid email format";
        exit;
    }

    if (strlen($password) < 8) {
        echo "Password must be at least 8 characters long.";
        exit;
    }

    $hashed_password = password_hash($password, PASSWORD_DEFAULT);

    $verification_token = bin2hex(random_bytes(50));

    $query = "INSERT INTO users (username, email, password, role, status, verification_token) VALUES (?, ?, ?, ?, 'inactive', ?)";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("sssss", $username, $email, $hashed_password, $role, $verification_token);

    if ($stmt->execute()) {
        sendVerificationEmail($email, $verification_token);
        
        echo "Registration successful! Please check your email to verify your account.";
    } else {
        error_log("MySQL error: " . $stmt->error);
        echo "Something went wrong, please try again later.";
    }


function sendVerificationEmail($email, $verification_token) {
    $mail = new PHPMailer(true);
    try {
        $mail->isSMTP();
        $mail->Host = '';
        $mail->SMTPAuth = true;
        $mail->Username = '';
        $mail->Password = '';
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port = 587;

        $mail->setFrom('', 'cgd');
        $mail->addAddress($email);

        $mail->isHTML(true);
        $mail->Subject = 'Email Verification for Career Guidance';
        $mail->Body    = "Hi, <br><br>Thank you for registering! Please click the link below to verify your email address: <br><br><a href='http://yourdomain.com/verify.php?token=$verification_token'>Verify Email</a>";

        $mail->send();
    } catch (Exception $e) {
        echo "Mailer Error: " . $mail->ErrorInfo;
    }
}
}