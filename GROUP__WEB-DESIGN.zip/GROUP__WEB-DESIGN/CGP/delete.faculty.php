<?php
//();
if ($_SESSION['role'] !== 'institute') {
    header("Location: login.php");
    exit;
}


include('db_connection.php');

if (isset($_GET['id'])) {
    $institution_id = $_GET['id'];

    $query = "DELETE FROM faculties WHERE faculty_id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $faculty_id);

    if ($stmt->execute()) {
        header("Location: institute_dashboard.php");
    } else {
        echo "Error: " . $stmt->error;
    }
}

