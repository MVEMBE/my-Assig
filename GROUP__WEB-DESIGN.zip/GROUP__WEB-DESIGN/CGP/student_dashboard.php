<?php
session_start();
if ($_SESSION['role'] !== 'student') {
    header("Location: login.php");
    exit;
}

include('db_connection.php');

$query = "SELECT * FROM courses";
$result = $conn->query($query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Dashboard</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="man">
        <header>
            <h2>Student Dashboard</h2>
        </header>
        
        <h3>Available Courses</h3>
        <table>
            <tr>
                <th>Course Name</th>
                <th>Action</th>
            </tr>
        <?php while ($course = $result->fetch_assoc()) { ?>
            <tr>
                <td><?= $course['name']; ?></td>
                <td><a href="apply_for_course.php?course_id=<?= $course['course_id']; ?>">Apply</a></td>
            </tr>
            <?php } ?>
        </table>
    </div>
</body>
</html>
