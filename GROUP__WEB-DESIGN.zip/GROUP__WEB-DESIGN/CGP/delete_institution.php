<?php
session_start();
if ($_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit;
}

include('db_connection.php');

if (isset($_GET['id'])) {
    $institution_id = $_GET['id'];

    $query = "SELECT COUNT(*) FROM courses WHERE institution_id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $institution_id);
    $stmt->execute();
    $stmt->bind_result($num_courses);
    $stmt->fetch();

    if ($num_courses > 0) {
        echo "Cannot delete this institution as it has linked courses.";
        exit;
    }

    $query = "DELETE FROM institutions WHERE institution_id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $institution_id);

    if ($stmt->execute()) {
        echo "Action successful!";
        header("Location: admin_dashboard.php");
    }else {
        error_log("MySQL error: " . $stmt->error);
        echo "Something went wrong, please try again later.";
    }
}

