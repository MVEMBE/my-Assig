<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Career Guidance Platform</title>
    <link rel="stylesheet" href="losign.css">
    <link href="https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css" rel="stylesheet">
</head>
<body>
     <main>
        <div class="wrapper">
            <span class="big-animate2"></span>
            <div class="aform">
            <div class="form-box Register">
                <h2>Sign Up</h2>
                <form action="signup_process.php" method="POST">
                    <div class="input-box">
                        <input type="username" name="username" id="username" required>
                        <label for="username">UserName</label>
                        <i class="bx bxs-user"></i>
                    </div>
    
                    <div class="input-box">
                        <input type="email"  name="email" id="email" required>
                        <label for="email">Email</label>
                        <i class="bx bxs-envelope"></i>
                    </div>
    
                    <div class="input-box">
                        <input type="password" password="password" id="password" required>
                        <label for="password">Password</label>
                        <i class="bx bxs-lock-alt"></i>
                    </div>

                    <div class="roles">
                        <label for="role" class="rol">Role</label>
                        <select name="role" id="role" required>
                            <option value="">None</option>
                            <option value="student">Student</option>
                            <option value="institute">Institute</option>
                        </select>
                    </div>
    
                    <div class="d-btn">
                        <button type="reset" name="reset" class="btn">Reset</button>
                        <button type="Submit" name="signup" class="btn">Sign-up</button>
                    </div>
                    
                    <div class="logreg-link">
                        <p> Already registered?? <a href="login.php" class="signup-link">Log In</a></p>
                    </div>
                </form>
            </div>

            <div class="info-text register">
                <h2>Sign-Up</h2>
                <!--<p>Students are supposed to specify <br>their details here</p>-->
            </div>
            </div>
        </div>    
     </main>
    <script src="script.js"></script>
</body>
</html>