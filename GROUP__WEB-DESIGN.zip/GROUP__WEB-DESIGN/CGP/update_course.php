<?php

require_once 'db_connection.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    
    $course_id = $_POST['course_id'];
    $name = $_POST['name'];

    $query = "UPDATE students SET name = ? WHERE course_id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("sssisi", $name, $course_id);

    if ($stmt->execute()) {
        echo "Course information updated successfully!";
    } else {
        echo "Error updating Course!: " . $stmt->error;
    }

    $stmt->close();
    
    header("Location: institute_dashboard.php?");
    exit;
}

