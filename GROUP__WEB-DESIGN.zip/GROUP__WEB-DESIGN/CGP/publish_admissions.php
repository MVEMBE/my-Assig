<?php

session_start();
if ($_SESSION['role'] !== 'institute') {
    header("Location: login.php");
    exit;
}

include('db_connection.php');

if (isset($_POST['publish'])) {
    $course_id = $_POST['course_id'];
    $open_status = $_POST['open_status'];

    $query = "UPDATE admissions SET open_status = ? WHERE course_id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("si", $open_status, $course_id);

    if ($stmt->execute()) {
        echo "Admissions status updated successfully!";
    } else {
        echo "Error: " . $stmt->error;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Publish-Admissions</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="man">
        <header>
            <h1>Publish-Admissions</h1>
        </header>
        <form action="publish_admissions.php" method="POST">
            <select name="course_id" class="sho">
                <!-- Available courses -->
            </select>
            <select name="open_status" class="sho">
                <option value="open">Open</option>
                <option value="closed">Closed</option>
            </select>
            <button type="submit" name="publish">Publish</button>
        </form>
    </div>
</body>
</html>