<?php
session_start();
if ($_SESSION['role'] !== 'institute') {
    header("Location: login.php");
    exit;
}

include('db_connection.php');

$institution_id = $_SESSION['institution_id'];

$query = "SELECT a.application_id, u.username, c.name as course_name, a.application_status
          FROM applications a
          JOIN users u ON a.student_id = u.user_id
          JOIN courses c ON a.course_id = c.course_id
          WHERE c.faculty_id IN (SELECT faculty_id FROM faculties WHERE institution_id = ?)";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $institution_id);
$stmt->execute();
$result = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Applications</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="man">
        <header>
            <h2>View Applications</h2>
        </header>
        <table>
            <tr>
                <th>Student Name</th>
                <th>Course</th>
                <th>Status</th>
                <th>Actions</th>
            </tr>
            <?php while ($application = $result->fetch_assoc()) { ?>
            <tr>
                <td><?= $application['username']; ?></td>
                <td><?= $application['course_name']; ?></td>
                <td><?= $application['application_status']; ?></td>
                <td>
                    <a href="update_application_status.php?application_id=<?= $application['application_id']; ?>&status=accepted">Accept</a> |
                    <a href="update_application_status.php?application_id=<?= $application['application_id']; ?>&status=rejected">Reject</a>
                </td>
            </tr>
            <?php } ?>
        </table>
    </div>
</body>
</html>
