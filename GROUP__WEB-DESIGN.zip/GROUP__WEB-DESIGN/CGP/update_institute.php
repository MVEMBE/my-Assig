<?php

require_once 'db_connection.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    $institution_id = $_POST['institution_id'];
    $name = $_POST['name'];
    $type = $_POST['type'];
    $address = $_POST['address'];
    $contact = $_POST['contact'];

    $query = "UPDATE students SET name = ?, type = ?, address = ?, contact = ? WHERE institution_id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("sssisi", $name, $type, $address, $contact, $institution_id);

    if ($stmt->execute()) {
        echo "Institute information updated successfully!";
    } else {
        echo "Error updating Institute: " . $stmt->error;
    }

    $stmt->close();
    
    header("Location: admin_dashboard.php?id=" . $id);
    exit;
}
