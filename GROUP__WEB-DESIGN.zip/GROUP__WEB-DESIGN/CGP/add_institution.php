<?php
session_start();
if ($_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit;
}

include('db_connection.php');

if (isset($_POST['add_institution'])) {
    $name = $_POST['name'];
    $type = $_POST['type'];
    $address = $_POST['address'];
    $contact = $_POST['contact'];

    $query = "INSERT INTO institutions (name, type, address, contact) VALUES (?, ?, ?, ?)";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("ssss", $name, $type, $address, $contact);

    if ($stmt->execute()) {
        header("Location: admin_dashboard.php");
    } else {
        echo "Error: " . $stmt->error;
    }
}
