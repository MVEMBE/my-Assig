
<?php
//();
if ($_SESSION['role'] !== 'institute') {
    header("Location: login.php");
    exit;
}

include('db_connection.php');

if (isset($_POST['add_course'])) {
    $name = $_POST['name'];
    $institution_id = $_SESSION['institution_id'];

    $query = "INSERT INTO courses (name, course_id) VALUES (?, ?)";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("si", $name, $institution_id);

    if ($stmt->execute()) {
        header("Location: institute_dashboard.php");
    } else {
        echo "Error: " . $stmt->error;
    }
}