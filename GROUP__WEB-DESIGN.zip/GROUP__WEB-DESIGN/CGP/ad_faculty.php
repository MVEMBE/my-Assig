
<?php
session_start();
if ($_SESSION['role'] !== 'institute') {
    header("Location: login.php");
    exit;
}

include('db_connection.php');

$institution_id = $_SESSION['institution_id'];

$query = "SELECT * FROM faculties WHERE institution_id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $institution_id);
$stmt->execute();
$faculties_result = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Institute Dashboard</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="man">
        <header>
            <h3>Institute Dashboard</h3>
        </header>
        <div>
            <button class="cann"><a href="institute_dashboard.php">Cancel</a></button>
        </div>
    

        <form action="add_faculty.php" method="POST">
        <h3>Add Faculty</h3>
            <input type="text" name="name" placeholder="Faculty Name" required>
            <button type="submit" name="add_faculty">Add Faculty</button>
        </form>
    </div>
</body>
</html>
